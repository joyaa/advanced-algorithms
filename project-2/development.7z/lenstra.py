def init( n, seed ):
    u = ( seed*seed - 5 ) % n
    v = 4*seed % n
 
    num = pow(v-u, 3, n) * (3*u + v) % n
    den = 4 * pow(u,3,n) * v % n
 
    A = num, den
    P = (pow(u, 3, n), pow( v, 3, n) )
    return A, P
 
 
def add( p1, p2, p0, n ):
    x1,z1 = p1
    x2,z2 = p2
    x0,z0 = p0
 
    t1 = (x1-z1)*(x2+z2)
    t2 = (x1+z1)*(x2-z2)
 
    newx = z0 * pow( t1 + t2, 2, n ) % n
    newz = x0 * pow( t1 - t2, 2, n ) % n
 
    return newx, newz
 
 
def double( p, A, n ):
        x,z = p
        An, Ad = A
 
        t1 = pow(x + z, 2, n)
        t2 = pow(x - z, 2, n)
        t = t1 - t2
 
        newx = t1 * t2 * 4 * Ad % n
        newz = (4 * Ad * t2 + t * An) * t % n
 
        return newx, newz
 
def multiply( m, p, A, n ):
    if m == 0:
        return 0,0
    elif m == 1:
        return p
    else:
        q = double( p, A, n )
 
        if m == 2:
            return q
 
        b = 1
        while b < m:
            b <<= 1
        b >>= 2
 
        r = p
        while b:
            if m&b:
                q, r = double(q, A, n), add(q, r, p, n)
            else:
                q, r = add(r, q, p, n), double(r, A, n)
            b >>= 1
        return r
 
n,s = 5569379,4921134
A, P1 = init(n, s)
P2 = double(P1,A,n)
P3 = add(P2,P1,P1,n)
P4 = double(P2, A, n)
P6 = double(P3, A, n)
P7 = add(P4,P3,P1,n)
P13 = add(P6,P7,P1,n)
P13a = multiply(13,P1,A,n)
 
print P13, P13a, P13 == P13a