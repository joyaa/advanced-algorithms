from math import floor, sqrt
def squfof(N):
    P = {}
    Q = {}
    sqN = sqrt(N)
    P[0]=floor(sqN)
    Q[0]=1
    Q[1]=N-P[0]**2
    i = 1

    while not (is_square(Q[i])):
      b=floor(floor(sqN+P[i-1])/Q[i])
      P[i]=b*Q[i]-P[i-1]
      Q[i+1]=Q[i-1]+b*(P[i-1]-P[i])
      i+=1

    
    b=floor((floor(sqN)+P[i-1])/Q[i])
    P[0]=b*Q[i]-P[i-1]
    Q[0]=sqrt(Q[i])
    Q[1]=(N-P[0]**2)/Q[0]

    q = {}; p = {}
    q[0] = Q[1]
    p[0] = P[0]
    q[1] = Q[0]

    i = 1
    print len(P)
    while True:
      b=floor(floor(sqN+P[i-1])/Q[i])
      P[i]=b*Q[i]-P[i-1]
      Q[i+1]=Q[i-1]+b*(P[i-1]-P[i])

      b=floor(floor(sqN+p[i-1])/q[i])
      p[i]=b*q[i]-p[i-1]
      q[i+1]=q[i-1]+b*(p[i-1]-p[i])
      
      if P[i]==P[i-1]:
        pp = Q[i]
        break
      if p[i]==p[i-1]:
        pp = q[i]
        break
      i+=1
      
    return gcd(pp,N) 

def is_square(apositiveint):
  x = apositiveint // 2
  seen = set([x])
  while x * x != apositiveint:
    x = (x + (apositiveint // x)) // 2
    if x in seen: return False
    seen.add(x)
  return True

def gcd(x, y):
    while y:
        x, y = y, x%y
    return abs(x)

print squfof(99999989237606677)